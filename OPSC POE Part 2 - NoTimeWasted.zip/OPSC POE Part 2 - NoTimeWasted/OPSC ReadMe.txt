#No Time Wasted
The No Time Wasted App is an Android application developed using Android Studio and written in Kotlin. It allows users to log in, create timesheet entries, manage categories, and track the time spent on different activities.

#Features
The App No Time Wasted includes the following features:

User authentication: Users can log in to the app using a username and password. They can also sign up for a new account.

Category management: Users can create categories to group their timesheet entries. This allows for better organization and tracking.

Timesheet entry creation: Users can create timesheet entries by specifying the date, start and end times, description, and category. They can also optionally attach photographs to each entry.

Goal setting: Users can set a minimum and maximum daily goal for the number of hours worked.

Timesheet entry and category tracking: Users can view a list of all timesheet entries created during a selectable period. If a photo was stored for an entry, it can be accessed from this list. Users can also view the total number of hours spent on each category during a selectable period.

#Installation
To run the No Time Wasted App, follow these steps:

Ensure that you have Android Studio installed on your system. If not, you can download it from the official website: Android Studio.

Clone the project repository from GitHub. 

Open Android Studio and select "Open an existing Android Studio project." Browse to the location where you cloned the repository and select the project.

Android Studio will build the project and install any necessary dependencies automatically.

Use an emulator to run the application. Click on the "Run" button in Android Studio or use the gradle command-line tool.


#Technologies Used
The App No Time Wasted is developed using the following technologies:

Android Studio: The official integrated development environment (IDE) for Android app development.

Kotlin: programming language used for developing Android applications. 